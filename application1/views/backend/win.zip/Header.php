<!DOCTYPE html>



<html lang="en" dir="">



<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Win & Save</title>
    <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,400i,600,700,800,900" rel="stylesheet" />
   <link href="venders/dist-assets/css/themes/lite-purple.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="venders/dist-assets/css/plugins/perfect-scrollbar.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="venders/dist-assets/css/plugins/datatables.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <style type="text/css">
     .table-responsive
     {
        height: 80vh;
     }
 </style>
</head>

<body class="text-left">
    <div class="app-admin-wrap layout-sidebar-large">
        <div class="main-header">
            <div class="logo">
                <img src="venders/images/logo.png" alt="">
            </div>
            <div class="menu-toggle">
                <div></div>
                <div></div>
                <div></div>
            </div>
            <div class="d-flex align-items-center">
                <!-- Mega menu -->
           
                <!-- / Mega menu -->
                <div class="search-bar">
                    <input type="text" placeholder="Search">
                    <i class="search-icon text-muted i-Magnifi-Glass1"></i>
                </div>
            </div>
            <div style="margin: auto"></div>
         
        </div>




<div class="side-content-wrap">
            <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                <ul class="navigation-left">
                    <li class="nav-item"><a class="nav-item-hold" href="dashboard"><i class="nav-icon i-Bar-Chart"></i><span class="nav-text">Dashboard</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="uikits"><a class="nav-item-hold" href="#"><i class="nav-icon i-Library"></i><span class="nav-text">Vendors</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="extrakits"><a class="nav-item-hold" href="#"><i class="nav-icon i-Suitcase"></i><span class="nav-text">Users</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="apps"><a class="nav-item-hold" href="#"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Manage Plans</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="managers"><a class="nav-item-hold" href="vender-aminity"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Manage Managers</span></a>
                        <div class="triangle"></div>
                    </li>

                     <li class="nav-item" data-item="support"><a class="nav-item-hold" href="vender-aminity"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Support</span></a>
                        <div class="triangle"></div>
                    </li>

                     <li class="nav-item" data-item="manage_ads"><a class="nav-item-hold" href="vender-aminity"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Manage Ads</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="category"><a class="nav-item-hold" href="Inventory-list"><i class="nav-icon i-File-Clipboard-File--Text"></i><span class="nav-text">Category</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="Order-list"><i class="nav-icon i-File-Clipboard-File--Text"></i><span class="nav-text">Orders</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="Inventory-list"><i class="nav-icon i-File-Horizontal-Text"></i><span class="nav-text">Inventory</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="level-list"><i class="nav-icon i-Administrator"></i><span class="nav-text">Manage Level</span></a>
                        <div class="triangle"></div>
                    </li>
                     
                       <li class="nav-item"><a class="nav-item-hold" href="about-us"><i class="nav-icon i-Administrator"></i><span class="nav-text">About us</span></a>
                        <div class="triangle"></div>
                    </li>

                      <li class="nav-item"><a class="nav-item-hold" href="contact"><i class="nav-icon i-Administrator"></i><span class="nav-text">Contact us</span></a>
                        <div class="triangle"></div>
                    </li>

                      <li class="nav-item"><a class="nav-item-hold" href="profile"><i class="nav-icon i-Administrator"></i><span class="nav-text">My Profile</span></a>
                        <div class="triangle"></div>
                    </li>

                      <li class="nav-item"><a class="nav-item-hold" href="Setting"><i class="nav-icon i-Administrator"></i><span class="nav-text">Points</span></a>
                        <div class="triangle"></div>
                    </li>

                    <li class="nav-item active"><a class="nav-item-hold" href="backend/Login/logout"><i class="nav-icon i-Double-Tap"></i><span class="nav-text">Logout</span></a>
                        <div class="triangle"></div>
                    </li>
                 
                </ul>
            </div>
            <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                <!-- Submenu Dashboards-->
                <ul class="childNav" data-parent="managers">
                    <li class="nav-item"><a href="all-manager"><i class="nav-icon i-Clock-3"></i><span class="item-name">Managers List</span></a></li>
                    <li class="nav-item"><a href="add-Manager"><i class="nav-icon i-Clock-4"></i><span class="item-name">Add Managers</span></a></li>
                   <!--  <li class="nav-item"><a href="dashboard3.php"><i class="nav-icon i-Over-Time"></i><span class="item-name">Version 3</span></a></li>
                    <li class="nav-item"><a href="dashboard4.php"><i class="nav-icon i-Clock"></i><span class="item-name">Version 4</span></a></li> -->
                </ul>
                <ul class="childNav" data-parent="manage_ads">
                    <li class="nav-item"><a href="slide-ads"><i class="nav-icon i-File-Clipboard-Text--Image"></i><span class="item-name">Slide Ads</span></a></li>
                    <li class="nav-item"><a href="Offer-list"><i class="nav-icon i-Split-Vertical"></i><span class="item-name">Feature Deal & Offers</span></a></li>
                    <li class="nav-item"><a href="Classified-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Classified Offers</span></a></li>
                    <li class="nav-item"><a href="Limited-offer-list"><i class="nav-icon i-Close-Window"></i><span class="item-name">Limited Offers</span></a></li>
                    <li class="nav-item"><a href="news-save"><i class="nav-icon i-Width-Window"></i><span class="item-name">News and Offers</span></a></li>
             
                </ul>
                <ul class="childNav" data-parent="apps">
                    <li class="nav-item"><a href="create-plans"><i class="nav-icon i-Add-File"></i><span class="item-name">Create Plans</span></a></li>
                    <li class="nav-item"><a href="plan-list"><i class="nav-icon i-Email"></i><span class="item-name">Plan List</span></a></li>
                    <li class="nav-item"><a href="manage_accounts.php"><i class="nav-icon i-Speach-Bubble-3"></i><span class="item-name">Manage Acccounts</span></a></li>
                </ul>
                <ul class="childNav" data-parent="category">
                    <li class="nav-item"><a href="category-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Category List</span></a></li>
                   <li class="nav-item"><a href="sub-category-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Sub-Category List</span></a></li>
                    <li class="nav-item"><a href="aminity-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Aminity List <span class="ml-2 badge badge-pill badge-danger">New</span></span></a></li>
                   
                </ul>
           
                <ul class="childNav" data-parent="extrakits">
                     <li class="nav-item"><a href="add-user"><i class="nav-icon i-Crop-2"></i><span class="item-name">Add User</span></a></li>
                    <li class="nav-item"><a href="all-users"><i class="nav-icon i-Crop-2"></i><span class="item-name">Users's List</span></a></li>
                     <li class="nav-item"><a href="User-transaction"><i class="nav-icon i-Loading-3"></i><span class="item-name">User Transitions</span></a></li>
                    <li class="nav-item"><a href="User-membership"><i class="nav-icon i-Loading-2"></i><span class="item-name">User Memberships</span></a></li>
                 
                </ul>
                <ul class="childNav" data-parent="uikits">
                     <li class="nav-item"><a  href="add-vender"><i class="nav-icon i-Bell1"></i><span class="item-name">Add Vender</span></a></li>
                    <li class="nav-item"><a  href="venders-verification-list"><i class="nav-icon i-Bell1"></i><span class="item-name">New Vendor Verification</span></a></li>
                    <li class="nav-item"><a href="all-venders"><i class="nav-icon i-Split-Horizontal-2-Window"></i><span class="item-name">All Verify Vendor's</span></a></li>
                    <li class="nav-item"><a href="Vender-transaction"><i class="nav-icon i-Medal-2"></i><span class="item-name">Vendor Transitions</span></a></li>
                    <li class="nav-item"><a href="plan-list"><i class="nav-icon i-Cursor-Click"></i><span class="item-name">Vendor Memberships</span></a></li>
        
                </ul>
                <ul class="childNav" data-parent="support">
                    <li class="nav-item"><a href="#"><i class="nav-icon i-Checked-User"></i><span class="item-name">Vendor Support</span></a></li>
                    <li class="nav-item"><a href="#"><i class="nav-icon i-Add-User"></i><span class="item-name">User Support</span></a></li>
                    <li class="nav-item"><a href="help"><i class="nav-icon i-Find-User"></i><span class="item-name">Help</span></a></li>
                     <li class="nav-item"><a href="rules"><i class="nav-icon i-Find-User"></i><span class="item-name">Rules</span></a></li>
                </ul>
                <ul class="childNav" data-parent="others">
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/not-found.php"><i class="nav-icon i-Error-404-Window"></i><span class="item-name">Not Found</span></a></li>
                    <li class="nav-item"><a href="user.profile.php"><i class="nav-icon i-Male"></i><span class="item-name">User Profile</span></a></li>
                    <li class="nav-item"><a class="open" href="blank.php"><i class="nav-icon i-File-Horizontal"></i><span class="item-name">Blank Page</span></a></li>
                </ul>
            </div>
            <div class="sidebar-overlay"></div>
        </div>




         

  <div class="side-content-wrap">
            <div class="sidebar-left open rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                <ul class="navigation-left">
                    <li class="nav-item"><a class="nav-item-hold" href="dashboard"><i class="nav-icon i-Bar-Chart"></i><span class="nav-text">Dashboard</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="uikits"><a class="nav-item-hold" href="#"><i class="nav-icon i-Library"></i><span class="nav-text">Vendors</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="extrakits"><a class="nav-item-hold" href="#"><i class="nav-icon i-Suitcase"></i><span class="nav-text">Users</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="apps"><a class="nav-item-hold" href="#"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Manage Plans</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="managers"><a class="nav-item-hold" href="vender-aminity"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Manage Managers</span></a>
                        <div class="triangle"></div>
                    </li>

                     <li class="nav-item" data-item="support"><a class="nav-item-hold" href="vender-aminity"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Support</span></a>
                        <div class="triangle"></div>
                    </li>

                     <li class="nav-item" data-item="manage_ads"><a class="nav-item-hold" href="vender-aminity"><i class="nav-icon i-Computer-Secure"></i><span class="nav-text">Manage Ads</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item" data-item="category"><a class="nav-item-hold" href="Inventory-list"><i class="nav-icon i-File-Clipboard-File--Text"></i><span class="nav-text">Category</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="Order-list"><i class="nav-icon i-File-Clipboard-File--Text"></i><span class="nav-text">Orders</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="Inventory-list"><i class="nav-icon i-File-Horizontal-Text"></i><span class="nav-text">Inventory</span></a>
                        <div class="triangle"></div>
                    </li>
                    <li class="nav-item"><a class="nav-item-hold" href="level-list"><i class="nav-icon i-Administrator"></i><span class="nav-text">Manage Level</span></a>
                        <div class="triangle"></div>
                    </li>
                     
                       <li class="nav-item"><a class="nav-item-hold" href="about-us"><i class="nav-icon i-Administrator"></i><span class="nav-text">About us</span></a>
                        <div class="triangle"></div>
                    </li>

                      <li class="nav-item"><a class="nav-item-hold" href="contact"><i class="nav-icon i-Administrator"></i><span class="nav-text">Contact us</span></a>
                        <div class="triangle"></div>
                    </li>

                      <li class="nav-item"><a class="nav-item-hold" href="profile"><i class="nav-icon i-Administrator"></i><span class="nav-text">My Profile</span></a>
                        <div class="triangle"></div>
                    </li>

                      <li class="nav-item"><a class="nav-item-hold" href="Setting"><i class="nav-icon i-Administrator"></i><span class="nav-text">Points</span></a>
                        <div class="triangle"></div>
                    </li>

                    <li class="nav-item active"><a class="nav-item-hold" href="backend/Login/logout"><i class="nav-icon i-Double-Tap"></i><span class="nav-text">Logout</span></a>
                        <div class="triangle"></div>
                    </li>
                  <!--   <li class="nav-item"><a class="nav-item-hold" href="http://demos.ui-lib.com/gull-html-doc/" target="_blank"><i class="nav-icon i-Safe-Box1"></i><span class="nav-text">Doc</span></a>
                        <div class="triangle"></div>
                    </li> -->
                </ul>
            </div>
            <div class="sidebar-left-secondary rtl-ps-none" data-perfect-scrollbar="" data-suppress-scroll-x="true">
                <!-- Submenu Dashboards-->
                <ul class="childNav" data-parent="managers">
                    <li class="nav-item"><a href="all-manager"><i class="nav-icon i-Clock-3"></i><span class="item-name">Managers Lis</span></a></li>
                    <li class="nav-item"><a href="add-Manager"><i class="nav-icon i-Clock-4"></i><span class="item-name">Add Managers</span></a></li>
                   <!--  <li class="nav-item"><a href="dashboard3.php"><i class="nav-icon i-Over-Time"></i><span class="item-name">Version 3</span></a></li>
                    <li class="nav-item"><a href="dashboard4.php"><i class="nav-icon i-Clock"></i><span class="item-name">Version 4</span></a></li> -->
                </ul>
                <ul class="childNav" data-parent="manage_ads">
                    <li class="nav-item"><a href="slide-ads"><i class="nav-icon i-File-Clipboard-Text--Image"></i><span class="item-name">Slide Ads</span></a></li>
                    <li class="nav-item"><a href="Offer-list"><i class="nav-icon i-Split-Vertical"></i><span class="item-name">Feature Deal & Offers</span></a></li>
                    <li class="nav-item"><a href="Classified-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Classified Offers</span></a></li>
                    <li class="nav-item"><a href="Limited-offer-list"><i class="nav-icon i-Close-Window"></i><span class="item-name">Limited Offers</span></a></li>
                    <li class="nav-item"><a href="news-save"><i class="nav-icon i-Width-Window"></i><span class="item-name">News and Offers</span></a></li>
             
                </ul>
                <ul class="childNav" data-parent="apps">
                    <li class="nav-item"><a href="create-plans"><i class="nav-icon i-Add-File"></i><span class="item-name">Create Plans</span></a></li>
                    <li class="nav-item"><a href="plan-list"><i class="nav-icon i-Email"></i><span class="item-name">Plan List</span></a></li>
                    <li class="nav-item"><a href="manage_accounts.php"><i class="nav-icon i-Speach-Bubble-3"></i><span class="item-name">Manage Acccounts</span></a></li>
                </ul>
                <ul class="childNav" data-parent="category">
                    <li class="nav-item"><a href="category-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Category List</span></a></li>
                   <li class="nav-item"><a href="sub-category-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Sub-Category List</span></a></li>
                    <li class="nav-item"><a href="aminity-list"><i class="nav-icon i-Receipt-4"></i><span class="item-name">Aminity List <span class="ml-2 badge badge-pill badge-danger">New</span></span></a></li>
                
                </ul>
               
                <ul class="childNav" data-parent="extrakits">
                    <li class="nav-item"><a href="all-users"><i class="nav-icon i-Crop-2"></i><span class="item-name">Users's List</span></a></li>
                     <li class="nav-item"><a href="User-transaction"><i class="nav-icon i-Loading-3"></i><span class="item-name">User Transitions</span></a></li>
                    <li class="nav-item"><a href="User-membership"><i class="nav-icon i-Loading-2"></i><span class="item-name">User Memberships</span></a></li>
                   
                </ul>
                <ul class="childNav" data-parent="uikits">
                    <li class="nav-item"><a  href="venders-verification-list"><i class="nav-icon i-Bell1"></i><span class="item-name">New Vendor Verification</span></a></li>
                    <li class="nav-item"><a href="all-venders"><i class="nav-icon i-Split-Horizontal-2-Window"></i><span class="item-name">All Verify Vendor's</span></a></li>
                    <li class="nav-item"><a href="Vender-transaction"><i class="nav-icon i-Medal-2"></i><span class="item-name">Vendor Transitions</span></a></li>
                    <li class="nav-item"><a href="plan-list"><i class="nav-icon i-Cursor-Click"></i><span class="item-name">Vendor Memberships</span></a></li>
                  
                </ul>
                <ul class="childNav" data-parent="sessions">
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/signin.php"><i class="nav-icon i-Checked-User"></i><span class="item-name">Sign in</span></a></li>
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/signup.php"><i class="nav-icon i-Add-User"></i><span class="item-name">Sign up</span></a></li>
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/forgot.php"><i class="nav-icon i-Find-User"></i><span class="item-name">Forgot</span></a></li>
                </ul>
                <ul class="childNav" data-parent="others">
                    <li class="nav-item"><a href="http://demos.ui-lib.com/gull/html/sessions/not-found.php"><i class="nav-icon i-Error-404-Window"></i><span class="item-name">Not Found</span></a></li>
                    <li class="nav-item"><a href="user.profile.php"><i class="nav-icon i-Male"></i><span class="item-name">User Profile</span></a></li>
                    <li class="nav-item"><a class="open" href="blank.php"><i class="nav-icon i-File-Horizontal"></i><span class="item-name">Blank Page</span></a></li>
                </ul>
            </div>
            <div class="sidebar-overlay"></div>
        </div>








        

        
        <!-- =============== Left side End ================-->
        
        
        
        
        
          <!-- The Users Modal -->

                           <div class="modal" id="myModal">

                            <div class="modal-dialog">

                              <div class="modal-content">



                                <!-- Modal Header -->

                                <div class="modal-header">

                                  <h4 class="modal-title name">Vendor</h4>

                                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                                </div>



                                <!-- Modal body -->

                                <div class="modal-body">

                                  <div class="user_detail"></div>

                                  <div class="card user-card">

                                    <div class="card-header">

                                      <h5 class="">Profile</h5>

                                    </div>

                                    <div class="card-block">

                                      <div class="usre-image profile_pic">



                                      </div>

                                      <h6 class="f-w-600 m-t-25 m-b-10">Alessa Robert</h6>

                                      <p class="text-muted">Active | Male | Born 23.05.1992</p>

                                      <hr/>

                                      <p class="text-muted m-t-15">Activity Level: 87%</p>

                                      <ul class="list-unstyled activity-leval">

                                        <li class="active"></li>

                                        <li class="active"></li>

                                        <li class="active"></li>

                                        <li></li>

                                        <li></li>

                                      </ul>

                                      <div class="bg-c-blue counter-block m-t-10 p-20">

                                        <div class="row">

                                          <div class="col-4">

                                            <i class="ti-comments"></i>

                                            <p>1256</p>

                                          </div>

                                          <div class="col-4">

                                            <i class="ti-user"></i>

                                            <p>8562</p>

                                          </div>

                                          <div class="col-4">

                                            <i class="ti-bag"></i>

                                            <p>189</p>

                                          </div>

                                        </div>

                                      </div>

                                      <p class="m-t-15 text-muted">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                      <hr/>

                                      <div class="row justify-content-center user-social-link">

                                        <div class="col-auto"><a href="#!"><i class="fa fa-facebook text-facebook"></i></a></div>

                                        <div class="col-auto"><a href="#!"><i class="fa fa-twitter text-twitter"></i></a></div>

                                        <div class="col-auto"><a href="#!"><i class="fa fa-dribbble text-dribbble"></i></a></div>

                                      </div>

                                    </div>

                                  </div>

                                </div>



                                <!-- Modal footer -->

                                <div class="modal-footer">

                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

                                </div>



                              </div>

                            </div>

                          </div>

                          <!-- The Venders Modal -->

                          <div class="modal" id="myModal2">

                            <div class="modal-dialog">

                              <div class="modal-content">



                                <!-- Modal Header -->

                                <div class="modal-header">

                                  <h4 class="modal-title name">Vendor</h4>

                                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                                </div>



                                <!-- Modal body -->

                                <div class="modal-body">

                                  <div class="user_detail"></div>

                                  <div class="card user-card">

                                    <div class="card-header">

                                      <h5 class="">Profile</h5>

                                    </div>

                                    <div class="email"></div>



                                    <div class="national_id"></div>

                                    <div class="business_proof"></div>

                                    <div class="address"></div>

                                    <div class="latitude"></div>

                                    <div class="longitude"></div>

                                    <div class="contact"></div>

                                    <div class="city"></div>

                                    <div class="menu_pdf"></div>

                                    <div class="card-block">

                                      <div class="usre-image profile_pic">



                                      </div>

                                      <h6 class="f-w-600 m-t-25 m-b-10">Alessa Robert</h6>

                                      <p class="text-muted">Active | Male | Born 23.05.1992</p>

                                      <hr/>

                                      <p class="text-muted m-t-15">Activity Level: 87%</p>

                                      <ul class="list-unstyled activity-leval">

                                        <li class="active"></li>

                                        <li class="active"></li>

                                        <li class="active"></li>

                                        <li></li>

                                        <li></li>

                                      </ul>

                                      <div class="bg-c-blue counter-block m-t-10 p-20">

                                        <div class="row">

                                          <div class="col-4">

                                            <i class="ti-comments"></i>

                                            <p>1256</p>

                                          </div>

                                          <div class="col-4">

                                            <i class="ti-user"></i>

                                            <p>8562</p>

                                          </div>

                                          <div class="col-4">

                                            <i class="ti-bag"></i>

                                            <p>189</p>

                                          </div>

                                        </div>

                                      </div>

                                      <p class="m-t-15 text-muted">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                      <hr/>

                                      <div class="row justify-content-center user-social-link">

                                        <div class="col-auto"><a href="#!"><i class="fa fa-facebook text-facebook"></i></a></div>

                                        <div class="col-auto"><a href="#!"><i class="fa fa-twitter text-twitter"></i></a></div>

                                        <div class="col-auto"><a href="#!"><i class="fa fa-dribbble text-dribbble"></i></a></div>

                                      </div>

                                    </div>

                                  </div>

                                </div>



                                <!-- Modal footer -->

                                <div class="modal-footer">

                                  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>

                                </div>



                              </div>

                            </div>

                          </div>

                          <!-- News add model -->

                          <div class="modal" id="news-section">

                            <div class="modal-dialog">

                              <div class="modal-content">


   <form enctype="multipart/form-data"  accept-charset="utf-8" name="formname" id="formname"  method="post"  >

                                <!-- Modal Header -->

                                <div class="modal-header">

                                  <h4 class="modal-title">Add News Section</h4>

                                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                                </div>



                                <!-- Modal body -->

                                <div class="modal-body">

                                 <div class="row">



                                   <div class="col-xl-12">

                                     <!-- <form action="#" method="post"> -->

                                  
                                      <div class="form-group news_save" style="display: none;" id="successMessage">





                                       <div class="alert alert-success">

                                        <strong>News Save Successfully.</strong>

                                      </div>

                                    </div>

                                    <div class="form-group">

                                     <label>Title</label>

                                     <input type="text"  name="title" class="form-control title">

                                   </div>

                                   <div class="form-group">

                                     <label>text</label>

                                     <input type="text"  name="text" class="form-control text">

                                   </div>

                                   <div class="form-group">

                                     <label>Image</label>

                                     <input type="file" id="imag"  name="imag" class="form-control imag">

                                   </div> 


                               </div>

                             </div>

                           </div>



                           <!-- Modal footer -->

                           <div class="modal-footer">

                         
                            <input type="submit" value="submit"  onsubmit="hidemodel()" class="btn btn-danger save_news"/>

                          </div>
                          

                                 </form>

                        </div>

                      </div>

                    </div>

                    <!-- News update model -->

                    <div class="modal" id="news-update">

                      <div class="modal-dialog">

                        <div class="modal-content">



                          <!-- Modal Header -->

                          <div class="modal-header">

                            <h4 class="modal-title">Update News Section</h4>

                            <button type="button" class="close" data-dismiss="modal">&times;</button>

                          </div>



                          <!-- Modal body -->

                          <div class="modal-body">

                           <div class="row">



                             <div class="col-xl-12">

                               <form enctype="multipart/form-data"  accept-charset="utf-8" name="formname1" id="formname1"  method="post" action="" >

                                <div class="form-group news_update" style="display: none;" id="successMessage">

                                 <div class="alert alert-success">

                                  <strong>News Update Successfully.</strong>

                                </div>

                              </div>



                              <div class="form-group">

                               <label>Title</label>

                               <input type="text" id="title"  name="title" value="" class="form-control title">

                             </div>

                             <div class="form-group">

                               <label>text</label>



                               <input type="text" id="text" value="" name="text" class="form-control text">

                             </div>

                             <div class="form-group">

                               <label>Image</label>

                               <input type="file" id="imag" name="imag"  value="" class="form-control imag">

                               <div id="id_to"></div>

                             </div>



                           </form>

                         </div>

                       </div>

                     </div>



                     <!-- Modal footer -->

                     <div class="modal-footer">

                      <button type="submit" class="btn btn-danger update_news">submit</button>

                    </div>



                  </div>

                </div>

              </div>

              <!-- category Modal -->

              <div class="modal" id="category-section">

                <div class="modal-dialog">

                  <div class="modal-content">



                    <!-- Modal Header -->

                    <div class="modal-header">

                      <h4 class="modal-title">Add Category</h4>

                      <button type="button" class="close" data-dismiss="modal">&times;</button>

                    </div>



                    <!-- Modal body -->

                    <div class="modal-body">

                     <div class="row">

                       <div class="col-xl-12">



                        <form enctype="multipart/form-data" id="modal_form_id"  method="POST" >



                         <div class="form-group">

                           <label>Category Name</label>

                           <input type="text" name="name" id="name" class="form-control">

                         </div>



                         <div class="form-group">

                           <label>Image</label>

                           <input type="file" name="userfile" id="userfile" class="form-control">

                         </div>



                       </form>

                     </div>

                   </div>

                 </div>



                 <!-- Modal footer -->

                 <div class="modal-footer">

                  <button type="submit" class="btn btn-danger category_save">submit</button>

                </div>



              </div>

            </div>

          </div>

          <!-- category Modal update-->

          <div class="modal" id="category-update">

            <div class="modal-dialog">

              <div class="modal-content">



                <!-- Modal Header -->

                <div class="modal-header">

                  <h4 class="modal-title">Update Category</h4>

                  <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>



                <!-- Modal body -->

                <div class="modal-body">

                 <div class="row">

                   <div class="col-xl-12">



                    <form enctype="multipart/form-data" id="modal_form_id2"  method="POST" >



                     <div class="form-group">

                       <label>Category Name</label>

                       <input type="text" name="name" id="name" class="form-control name">

                     </div>

                     <input type="hidden" name="id" value="" class="id">

                     <input type="hidden" name="featured_image" value="" class="featured_image">

                     <div class="featured_image"></div>

                     <div class="form-group">

                       <label>Image</label>

                       <input type="file" name="userfile" id="userfile" class="form-control userfile">

                     </div>



                   </form>

                 </div>

               </div>

             </div>



             <!-- Modal footer -->

             <div class="modal-footer">

              <button type="submit" class="btn btn-danger category_update">submit</button>

            </div>



          </div>

        </div>

      </div>

      <!--sub category Modal -->

      <div class="modal" id="sub-category-section">

        <div class="modal-dialog">

          <div class="modal-content">



            <!-- Modal Header -->

            <div class="modal-header">

              <h4 class="modal-title">Add Sub Category</h4>

              <button type="button" class="close" data-dismiss="modal">&times;</button>

            </div>



            <!-- Modal body -->

            <div class="modal-body">

             <div class="row">

               <div class="col-xl-12">



                <form enctype="multipart/form-data" id="subcate"  method="POST" >

                  <div class="form-group">

                    <label>Category Name</label>

                    <select class="category_list form-control" name="c_id" id="c_id">

                      <option>Select Category</option>

                    </select>

                  </div>

                  <div class="form-group">

                   <label>Sub Category Name</label>

                   <input type="text" name="name" id="name" class="form-control">

                 </div>



                 <div class="form-group">

                   <label>Image</label>

                   <input type="file" name="userfile" id="userfile" class="form-control">

                 </div>



               </form>

             </div>

           </div>

         </div>



         <!-- Modal footer -->

         <div class="modal-footer">

          <button type="submit" class="btn btn-danger subcategory_save">submit</button>

        </div>



      </div>

    </div>

  </div>

  <!-- subcategory Modal update-->

  <div class="modal" id="subcategory-update">

    <div class="modal-dialog">

      <div class="modal-content">



        <!-- Modal Header -->

        <div class="modal-header">

          <h4 class="modal-title">Update SubCategory</h4>

          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>



        <!-- Modal body -->

        <div class="modal-body">

         <div class="row">

           <div class="col-xl-12">



            <form enctype="multipart/form-data" id="subcateupdate"  method="POST" >

              <div class="form-group">

                <label>Category Name</label>

                <select class="category_list form-control" name="c_id" id="c_id">

                  <option>Select Category</option>

                </select>

              </div>

              <div class="form-group">

               <label>SubCategory Name</label>

               <input type="text" name="name" id="name" class="form-control name">

             </div>

             <input type="hidden" name="id" value="" class="id">

             <input type="hidden" name="featured_image" value="" class="featured_image">

             <div class="featured_image"></div>

             <div class="form-group">

               <label>Image</label>

               <input type="file" name="userfile" id="userfile" class="form-control userfile">

             </div>



           </form>

         </div>

       </div>

     </div>



     <!-- Modal footer -->

     <div class="modal-footer">

      <button type="submit" class="btn btn-danger subcategory_update">submit</button>

    </div>



  </div>

</div>

</div>

<!-- Vender Offer Modal -->

<div class="modal" id="Vender_offer">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">



      <!-- Modal Header -->

      <div class="modal-header">

        <h4 class="modal-title">Offer Detail</h4>

        <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>



      <!-- Modal body -->

      <div class="modal-body">

       <div class="row">

         <div class="col-xl-12">



          <form enctype="multipart/form-data" id="subcateupdate"  method="POST" >



            <div class="row">

              <div class="col-xl-4">

                <div  class="offer_img"></div>

              </div>

              <div class="col-xl-8">

               <div class="view_information">

                 <div>offer title:</div> 

                 <div class="offer_title"></div>

               </div>



               <div class="view_information"> <div>offer_name:</div><div class="offer_name"></div></div>

               <div class="view_information"> <div>offer_detail:</div><div class="offer_detail"></div></div>

               <div class="view_information"> <div>valid_date:</div><div class="valid_date"></div></div>

               <div class="view_information"><div>limit_per_user:</div><div class="limit_per_user"></div></div>

               <div class="view_information"><div>stoke:</div><div class="stoke"></div></div>

               <div class="view_information"><div>used:</div><div class="used"></div></div>

               <div class="view_information"><div>offer_amount:</div><div class="offer_amount"></div></div>

               <div class="view_information"> <div>add_date:</div><div class="add_date"></div></div>

               <div class="view_information"> <div>status:</div><div class="status"></div></div>

             </div>

           </div>

         </div>







       </form>

     </div>

   </div>

 </div>





</div>

</div>

</div>

<!--Aminity Modal -->

<div class="modal" id="aminity-section">

  <div class="modal-dialog">

    <div class="modal-content">



      <!-- Modal Header -->

      <div class="modal-header">

        <h4 class="modal-title">Add Aminity</h4>

        <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>



      <!-- Modal body -->

      <div class="modal-body">

       <div class="row">

         <div class="col-xl-12">



          <form enctype="multipart/form-data" id="aminity"  method="POST" >

            <div class="form-group">

              <label>Category Name</label>

              <select class="category_list form-control" name="c_id" id="c_id">

                <option>Select Category</option>

              </select>

            </div>

            <div class="form-group">

             <label>Aminity Name</label>

             <input type="text" name="name" id="name" class="form-control">

           </div>



           <div class="form-group">

             <label>Image</label>

             <input type="file" name="userfile" id="userfile" class="form-control">

           </div>



         </form>

       </div>

     </div>

   </div>



   <!-- Modal footer -->

   <div class="modal-footer">

    <button type="submit" class="btn btn-danger aminity_save">submit</button>

  </div>



</div>

</div>

</div>

<!-- aminity update Modal update-->

<div class="modal" id="aminity-update">

  <div class="modal-dialog">

    <div class="modal-content">



      <!-- Modal Header -->

      <div class="modal-header">

        <h4 class="modal-title">Update Aminity</h4>

        <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>



      <!-- Modal body -->

      <div class="modal-body">

       <div class="row">

         <div class="col-xl-12">



          <form enctype="multipart/form-data" id="aminityupdate"  method="POST" >

            <div class="form-group">

              <label>Category Name</label>

              <select class="category_list form-control" name="c_id" id="c_id">

                <option>Select Category</option>

              </select>

            </div>

            <div class="form-group">

             <label>SubCategory Name</label>

             <input type="text" name="name" id="name" class="form-control name">

           </div>

           <input type="hidden" name="id" value="" class="id">

           <input type="hidden" name="featured_image" value="" class="featured_image">

           <div class="featured_image"></div>

           <div class="form-group">

             <label>Image</label>

             <input type="file" name="userfile" id="userfile" class="form-control userfile">

           </div>



         </form>

       </div>

     </div>

   </div>



   <!-- Modal footer -->

   <div class="modal-footer">

    <button type="submit" class="btn btn-danger aminity_update">submit</button>

  </div>



</div>

</div>

</div>

<!-- Rating Modal -->

<div class="modal" id="RatingmyModal">

  <div class="modal-dialog">

    <div class="modal-content">



      <!-- Modal Header -->

      <div class="modal-header">

        <h4 class="modal-title">User Rating Detail</h4>

        <button type="button" class="close" data-dismiss="modal">&times;</button>

      </div>



      <!-- Modal body -->

      <div class="modal-body">

       <div class="row">

         <div class="col-xl-12">



          <form enctype="multipart/form-data" id="aminityupdate"  method="POST" >



           <div class="form-group">

             <label class="review"></label>



           </div>





         </form>

       </div>

     </div>

   </div>





 </div>

</div>

</div>

<script>
    
    function hidemodel()
    {
        document.getElementById(news-section).style.display="none";
    }
    
    
</script>