
<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-body">
          <div class="row">
            <!-- order-card start -->
            <div class="col-sm-12">
              <h4 class="page-title">User's List</h4>
              <div class="card tabs-card">
                <div class="card-block p-0">
                  <!-- Tab panes -->
                  <div class="tab-content card-block">
                    <div class="tab-pane active" id="home3" role="tabpanel">
                      <div class="table-responsive">
                        <table class="table table-hover" id="example">
                          <thead>
                            <tr class="text-uppercase bg-primary">
                              <th>S.no</th>
                              <th>Image</th>
                              <th>Name</th>
                              <th>E-mail</th>
                              <th>Address</th>
                              <th>Contact</th>
                              <th>City</th>
                              <th>Create On</th>
                              <th>Status</th>
                              <th>View More</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $i=1;foreach ($all_user_list as $key) {?>
                            <tr>
                              <td>
                                <?php echo $i; ?>
                              </td>
                              <td>
                                <img style="width: 100%;border-radius: 7px;" src="<?php echo base_url();  ?>upload/<?php echo $key->profile_pic;  ?>">
                              </td>
                              <td>
                                <?php echo $key->name; ?></td>
                              <td>
                                <?php echo $key->email; ?></td>
                              <td>
                                <?php echo $key->address; ?></td>
                              <td>
                                <?php echo $key->contact; ?></td>
                              <td>
                                <?php echo $key->location; ?></td>
                              <td>
                                <?php echo date( "d/M/Y", strtotime($key->added_date) ); ?></td>
                              <td>
                                <form action="<?php echo base_url(); ?>backend/Login/status_update" method="POST">
                                  <input type="hidden" name="id" value="<?php echo $key->id; ?>">
                                  <input type="hidden" name="path" value="all-users">
                                  <input type="hidden" name="status" value="<?php if ($key->status==1) { echo " 0 ";}else{ echo "1 ";}
                ?>" ">
                <input type="submit" name=" " class="btn btn-<?php if ($key->status==1) { echo "success";}else{ echo "danger";} ?>" value="
                                  <?php if ($key->status==1) { echo "Apporved";}else{ echo "Disapporved";} ?>"></form>
                              </td>
                              <td><a href="#myModal" id="<?php echo $key->id;  ?>" data-toggle="modal" class="view_user"><span class="ti-eye"></span></a>
                              </td>
                            </tr>
                            <?php $i++;} ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- tabs card end -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $(document).ready(function(){  
        $('.view_user').click(function(){
          
             var user_id = $(this).attr("id"); 
             
             $.ajax({  
                  url:"<?php echo base_url(); ?>backend/Login/user_view",  
                  method:"post",  
                  data:{user_id:user_id},  
                  success:function(resonse){
                       var returnedData = JSON.parse(resonse);  
                       $('.name').html(returnedData.name);  
                       if(returnedData.profile_pic!==""){
                       $('.profile_pic').html('<img class="img-radius" src="<?php echo base_url(); ?>upload/' + returnedData.profile_pic + '"" >');
                     }else{
                        $('.profile_pic').html('<img class="img-radius" src="<?php echo base_url(); ?>upload/no_image.png "" >');
                      
                  }  
                     }
             });  
        });  
   });
</script>