<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-body">
          <div class="row">
            <!-- order-card start -->
            <div class="col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Contact us</h4>
                </div>
                <div class="card-body">
                  <form action="<?php echo base_url(); ?>aboutus" method="post" enctype="multipart/form-data">
                   
                    <div class="form-group">
                      <label for="">
                        <?php print_r($get_contactus[0][ 'detail']); ?>
                      </label>
                    </div>
                   
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>