<!DOCTYPE html>

<?php
$sessiondata = $this->session->userdata('Login'); $array = json_decode(json_encode($sessiondata), True);

$page = basename($_SERVER['PHP_SELF']);
 ?>
<html lang="en">

<head>
    <title>Win & Save</title>
   
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
 <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro&display=swap" rel="stylesheet">
      <!-- Favicon icon -->
      <link rel="icon" href="<?php echo base_url();  ?>venders/admin/assets/images/favicon.ico" type="image/x-icon">
      <!-- Google font-->
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600" rel="stylesheet">
      <!-- Required Fremwork -->
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>venders/admin/assets/css/bootstrap/css/bootstrap.min.css">
      <!-- themify-icons line icon -->
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>venders/admin/assets/icon/themify-icons/themify-icons.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>venders/admin/assets/icon/font-awesome/css/font-awesome.min.css">
      <!-- ico font -->
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>venders/admin/assets/icon/icofont/css/icofont.css">
      <!-- Style.css -->
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>venders/admin/assets/css/style.css">
      <link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>venders/admin/assets/css/jquery.mCustomScrollbar.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      
     <style>
     .view_information {
    display: flex;
    flex-direction: row;
    margin: 5px;
    padding: 5px;
}
         .view_information > div {
    text-transform: uppercase;
    font-weight: 700;
    display: flex;
    width: 100%;
}
      .view_information > div:last-child {
    background-color:rgba(0, 255, 0, 0.3607843137254902);
}
     </style> 
      
  </head>

  <body style="font-family: 'Source Sans Pro', sans-serif;">

  
       <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

            <nav class="navbar header-navbar pcoded-header">
               <div class="navbar-wrapper">
                   <div class="navbar-logo">
                       <a class="mobile-menu" id="mobile-collapse" href="#!">
                           <i class="ti-menu"></i>
                       </a>
                       <div class="mobile-search">
                           <div class="header-search">
                               <div class="main-search morphsearch-search">
                                   <div class="input-group">
                                       <span class="input-group-addon search-close"><i class="ti-close"></i></span>
                                       <input type="text" class="form-control" placeholder="Enter Keyword">
                                       <span class="input-group-addon search-btn"><i class="ti-search"></i></span>
                                   </div>
                               </div>
                           </div>
                       </div>
                       <a href="index.html">
                           <!-- <img class="img-fluid" src="../assets/img/logo.png" alt="Theme-Logo" /> -->
                          <h4> Win & Save </h4>
                       </a>
                       <a class="mobile-options">
                           <i class="ti-more"></i>
                       </a>
                   </div>

                   <div class="navbar-container container-fluid">
                       <ul class="nav-left">
                           <li>
                               <div class="sidebar_toggle"><a href="javascript:void(0)"><i class="ti-menu"></i></a></div>
                           </li>
                           <li class="header-search">
                               <div class="main-search morphsearch-search">
                                   <div class="input-group">
                                       <span class="input-group-addon search-close"><i class="ti-close"></i></span>
                                       <input type="text" class="form-control">
                                       <span class="input-group-addon search-btn"><i class="ti-search"></i></span>
                                   </div>
                               </div>
                           </li>
                           <li>
                               <a href="#!" onclick="javascript:toggleFullScreen()">
                                   <i class="ti-fullscreen"></i>
                               </a>
                           </li>
                       </ul>
                       <ul class="nav-right">
                           <!-- <li class="header-notification">
                               <a href="#!">
                                   <i class="ti-bell"></i>
                                   <span class="badge bg-c-pink"></span>
                               </a>
                               <ul class="show-notification">
                                   <li>
                                       <h6>Notifications</h6>
                                       <label class="label label-danger">New</label>
                                   </li>
                                   <li>
                                       <div class="media">
                                           <img class="d-flex align-self-center img-radius" src="assets/images/avatar-2.jpg" alt="Generic placeholder image">
                                           <div class="media-body">
                                               <h5 class="notification-user">John Doe</h5>
                                               <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
                                               <span class="notification-time">30 minutes ago</span>
                                           </div>
                                       </div>
                                   </li>
                                   <li>
                                       <div class="media">
                                           <img class="d-flex align-self-center img-radius" src="<?php echo base_url();  ?>venders/admin/assets/images/avatar-4.jpg" alt="Generic placeholder image">
                                           <div class="media-body">
                                               <h5 class="notification-user">Joseph William</h5>
                                               <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
                                               <span class="notification-time">30 minutes ago</span>
                                           </div>
                                       </div>
                                   </li>
                                   <li>
                                       <div class="media">
                                           <img class="d-flex align-self-center img-radius" src="assets/images/avatar-3.jpg" alt="Generic placeholder image">
                                           <div class="media-body">
                                               <h5 class="notification-user">Sara Soudein</h5>
                                               <p class="notification-msg">Lorem ipsum dolor sit amet, consectetuer elit.</p>
                                               <span class="notification-time">30 minutes ago</span>
                                           </div>
                                       </div>
                                   </li>
                               </ul>
                           </li> -->
                           
                           <li class="user-profile header-notification">
                               <a href="#!">
                                   <img src="<?php echo base_url();  ?>venders/admin/assets/images/avatar-4.jpg" class="img-radius" alt="User-Profile-Image">
                                   <span><?php print_r($array[0]['name']); ?></span>
                                   <i class="ti-angle-down"></i>
                               </a>
                               <ul class="show-notification profile-notification">
                                   <!-- <li>
                                       <a href="#!">
                                           <i class="ti-settings"></i> Settings
                                       </a>
                                   </li> -->
                                   <li>
                                       <a href="<?php  echo base_url();  ?>profile">
                                           <i class="ti-user"></i> Profile
                                       </a>
                                   </li>
                                   
                                  
                                   <li>
                                       <a href="<?php echo base_url(); ?>backend/Login/logout">
                                       <i class="ti-layout-sidebar-left"></i> Logout
                                   </a>
                                   </li>
                               </ul>
                           </li>
                       </ul>
                   </div>
               </div>
           </nav>
            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                   <nav class="pcoded-navbar">
                        <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
                        <div class="pcoded-inner-navbar main-menu">
                           
                            <div class="pcoded-navigatio-lavel" data-i18n="nav.category.navigation">Layout</div>
                            <?php 
                            // 0 type is for admin  
                            if($array[0]['type']==0){
                            ?>
                             <ul class="pcoded-item pcoded-left-item">
                                <li class="<?php echo ($page == "dashboard" ? "active" : "")?>">
                                    <a href="<?php echo base_url();  ?>dashboard">
                                        <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                                        <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                                <li class="pcoded-hasmenu <?php echo ($page == "venders-verification-list" || $page == "all-venders" || $page == "vendor_transitions.php" || $page == "vendor_membership.php" ? "active" : "")?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-panel"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Vendors</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo ($page == "vendor_list.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>venders-verification-list">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">New Vendor Verification</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "new_vendor_verification.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>all-venders">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">All Verify Vendor's</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "vendor_transitions.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url(); ?>Vender-transaction">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Vendor Transitions</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "vendor_membership.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>plan-list">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Vendor Memberships</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        

                                    </ul>
                                </li>
                                   <li class="pcoded-hasmenu <?php echo ($page == "all-users" || $page == "user_transitions.php" || $page == "user_memberships.php" ? "active" : "")?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-harddrives"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Users</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo ($page == "user_list.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>all-users">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">User's List</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" <?php echo ($page == "user_transitions.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url(); ?>User-transaction">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">User Transitions</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" <?php echo ($page == "user_memberships.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url(); ?>User-membership">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">User Memberships</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                     

                                        

                                    </ul>
                                </li>

                                   <li class="pcoded-hasmenu <?php echo ($page == "vendor_manage_account.php" || $page == "user_manage_account.php" || $page == "manage_accounts.php" ? "active" : "")?>">
                                   <a href="javascript:void(0)">
                                       <span class="pcoded-micon"><i class="ti-write"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Plans</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "vendor_manage_account.php" ? "active" : "")?> ">
                                           <a href="<?php echo base_url();  ?>create-plans">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Create Plans</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class="<?php echo ($page == "user_manage_account.php" ? "active" : "")?> ">
                                           <a href="<?php echo base_url();  ?>plan-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Plan List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "manage_accounts.php" ? "active" : "")?>">
                                           <a href="manage_accounts.php">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Manage Acccounts</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                    
                                    
                                       
                           
                                   </ul>
                               </li>
                                 <li class="pcoded-hasmenu <?php echo ($page == "all-manager" || $page == "add-Manager" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-book"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Managers</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "all-manager" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>all-manager">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Managers List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "add_managers.php" ? "active" : "")?>">
                                             <a href="<?php echo base_url(); ?>add-Manager">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Add Managers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                   
                                    
                                       
                           
                                   </ul>
                               </li>
                                 <li class="pcoded-hasmenu <?php echo ($page == "vendor_support.php" || $page == "user_support.php" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-book"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Support</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "vendor_support.php" ? "active" : "")?>">
                                           <a href="vendor_support.php">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Vendor Support</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "user_support.php" ? "active" : "")?>">
                                           <a href="user_support.php">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">User Support</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                   
                                    
                                       
                           
                                   </ul>
                               </li>
                                 <li class="pcoded-hasmenu <?php echo ($page == "slide-ads" || $page == "Offer-list" || $page == "Offer" || $page == "news-save" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-calendar"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Ads</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "slide_ads.php" ? "active" : "")?> ">
                                           <a href="<?php echo base_url(); ?>slide-ads">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Slide Ads</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "feature_deal.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>Offer-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Feature Deal & Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                        <li class=" <?php echo ($page == "feature_deal.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>Classified-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Classified Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                        <li class=" <?php echo ($page == "feature_deal.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>Limited-offer-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Limited Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                     <li class="<?php echo ($page == "news_verification.php" ? "active" : "")?> ">
                                           <a href="<?php echo base_url(); ?>news-save">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">News and Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                    
                                       
                           
                                   </ul>
                               </li>
                                <li class="pcoded-hasmenu <?php echo ($page == "category-list"   ? "active" : "" || $page == "sub-category-list"   ? "active" : "")?>">
                                   <a href="javascript:void(0)">
                                       <span class="pcoded-micon"><i class="ti-palette"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Category</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "category_list.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>category-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Category List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class="<?php echo ($page == "category_list.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>sub-category-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Sub-Category List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                        <li class="<?php echo ($page == "category_list.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>aminity-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Aminity List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                              
                                 
                                       
                           
                                   </ul>
                               </li>

                                     <li class="<?php echo ($page == "about.php" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>about-us">
                                       <span class="pcoded-micon"><i class="ti-harddrives"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">About us</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>

                                  <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>contact-us">
                                       <span class="pcoded-micon"><i class="ti-email"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Contact us</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>

                                    <li class="<?php echo ($page == "profile" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>profile">
                                       <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">My Profile</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                                    <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="contact.php">
                                       <span class="pcoded-micon"><i class="ti-settings"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Setting</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
     <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>backend/Login/logout">
                                       <span class="pcoded-micon"><i class="ti-power-off"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Logout</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>                               
                           </ul> 
                            </ul>
                            <?php } ?>
                             <?php 

                            // 1 type is for Venders  
                            if($array[0]['type']==1){
                            ?>
                            <ul class="pcoded-item pcoded-left-item">
                                <li class="<?php echo ($page == "dashboard" ? "active" : "")?>">
                                    <a href="<?php echo base_url();  ?>dashboard">
                                        <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                                        <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                                <li class="pcoded-hasmenu <?php echo ($page == "vendor_list.php" || $page == "new_vendor_verification.php" || $page == "vendor_transitions.php" || $page == "vendor_membership.php" ? "active" : "")?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-panel"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">My Offer</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo ($page == "vendor_list.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>My-offer">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Create Offer</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "new_vendor_verification.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>offer-list">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">My Offer List</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                         <li class="<?php echo ($page == "new_vendor_verification.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>offer-redeem">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Offer Redeem</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "new_vendor_verification.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>My-Redeem">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">My Redeem User List</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                       
                                       

                                    </ul>
                                </li>
                                 <li class="pcoded-hasmenu <?php echo ($page == "slide-ads" || $page == "Offer-list" || $page == "Offer" || $page == "news-save" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-calendar"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Ads</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       
                                       <li class=" <?php echo ($page == "feature_deal.php" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>Offer-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Feature Deal & Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                    
                                    
                                       
                           
                                   </ul>
                               </li>
                                   <li class="pcoded-hasmenu <?php echo ($page == "user_list.php" || $page == "user_transitions.php" || $page == "user_memberships.php" ? "active" : "")?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-harddrives"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">My Plans</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo ($page == "user_list.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>Get-plan">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Get Plan  </span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" <?php echo ($page == "user_transitions.php" ? "active" : "")?>">
                                            <a href="user_transitions.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">My Plan History</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" <?php echo ($page == "user_memberships.php" ? "active" : "")?>">
                                            <a href="user_memberships.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">My Memberships</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                     

                                        

                                    </ul>
                                </li>
                                <li class="<?php echo ($page == "profile" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>vender-profile">
                                       <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">My Profile</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                                <li class="<?php echo ($page == "profile" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>about">
                                       <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">About-us</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                                <li class="<?php echo ($page == "profile" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>contact">
                                       <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Contact-us</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                                <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>backend/Login/logout">
                                       <span class="pcoded-micon"><i class="ti-power-off"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Logout</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>        

                                   
                            </ul>
                            <?php } ?>
                             <?php 
                            // 2 type is for subadmin  
                            if($array[0]['type']==2){
                             $authority = (explode(",",$array[0]['authority']));
                            // print_r($authority[0]);
                            ?>
                             <ul class="pcoded-item pcoded-left-item">

                                <li class="<?php echo ($page == "dashboard" ? "active" : "")?>">
                                    <a href="<?php echo base_url();  ?>dashboard">
                                        <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                                        <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>
                                <?php 
                                 if($authority[0]==1){
                                ?>
                                <li class="pcoded-hasmenu <?php echo ($page == "venders-verification-list" || $page == "all-venders" || $page == "vendor_transitions.php" || $page == "vendor_membership.php" ? "active" : "")?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-panel"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Vendors</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo ($page == "vendor_list.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>venders-verification-list">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">New Vendor Verification</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "new_vendor_verification.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>all-venders">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">All Verify Vendor's</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "vendor_transitions.php" ? "active" : "")?>">
                                            <a href="vendor_transitions.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Vendor Transitions</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo ($page == "vendor_membership.php" ? "active" : "")?>">
                                            <a href="vendor_membership.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Vendor Memberships</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        

                                    </ul>
                                </li>
                              <?php } 
                                 if($authority[1]==2){
                                ?>
                                   <li class="pcoded-hasmenu <?php echo ($page == "all-users" || $page == "user_transitions.php" || $page == "user_memberships.php" ? "active" : "")?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-harddrives"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Users</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo ($page == "user_list.php" ? "active" : "")?>">
                                            <a href="<?php echo base_url();  ?>all-users">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">User's List</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" <?php echo ($page == "user_transitions.php" ? "active" : "")?>">
                                            <a href="#">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">User Transitions</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" <?php echo ($page == "user_memberships.php" ? "active" : "")?>">
                                            <a href="#">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">User Memberships</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                     

                                        

                                    </ul>
                                </li>
                                <?php } if($authority[2]==3){ ?>

                                   <li class="pcoded-hasmenu <?php echo ($page == "vendor_manage_account.php" || $page == "user_manage_account.php" || $page == "manage_accounts.php" ? "active" : "")?>">
                                   <a href="javascript:void(0)">
                                       <span class="pcoded-micon"><i class="ti-write"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Accounts</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "vendor_manage_account.php" ? "active" : "")?> ">
                                           <a href="#">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Vendor</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class="<?php echo ($page == "user_manage_account.php" ? "active" : "")?> ">
                                           <a href="#">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">User</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "manage_accounts.php" ? "active" : "")?>">
                                           <a href="manage_accounts.php">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Manage Acccounts</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                    
                                    
                                       
                           
                                   </ul>
                               </li>
                             <?php } if($authority[3]==4){ ?>
                                 <li class="pcoded-hasmenu <?php echo ($page == "add-Manager" || $page == "all-manager" ? "active" : "" || $page == "update-Manager" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-book"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Managers</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "all-manager" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>all-manager">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Managers List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "add-Manager" ? "active" : "")?>">
                                             <a href="<?php echo base_url(); ?>add-Manager">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Add Managers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                   
                                    
                                       
                           
                                   </ul>
                               </li>
                             <?php } if($authority[4]==5){ ?>
                                 <li class="pcoded-hasmenu <?php echo ($page == "vendor_support.php" || $page == "user_support.php" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-book"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Support</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "vendor_support.php" ? "active" : "")?>">
                                           <a href="vendor_support.php">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Vendor Support</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "user_support.php" ? "active" : "")?>">
                                           <a href="user_support.php">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">User Support</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                   
                                    
                                       
                           
                                   </ul>
                               </li>
                             <?php } if($authority[5]==6){ ?>
                                 <li class="pcoded-hasmenu <?php echo ($page == "slide-ads" || $page == "Offer-list" || $page == "news-save" || $page == "Offer" ? "active" : "")?>">
                                   <a href="#">
                                       <span class="pcoded-micon"><i class="ti-calendar"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Manage Ads</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "slide-ads" ? "active" : "")?> ">
                                           <a href="<?php echo base_url(); ?>slide-ads">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Slide Ads</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                       <li class=" <?php echo ($page == "Offer-list" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>Offer-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">Feature Deal & Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                     <li class="<?php echo ($page == "news-save" ? "active" : "")?> ">
                                           <a href="<?php echo base_url(); ?>news-save">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs">News and Offers</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                                    
                                       
                           
                                   </ul>
                               </li>
                             <?php } if($authority[6]==7){ ?>
                                <li class="pcoded-hasmenu <?php echo ($page == "category-list"   ? "active" : "")?>">
                                   <a href="javascript:void(0)">
                                       <span class="pcoded-micon"><i class="ti-palette"></i></span>
                                       <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Category</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                                   <ul class="pcoded-submenu">
                                       <li class="<?php echo ($page == "category-list" ? "active" : "")?>">
                                           <a href="<?php echo base_url(); ?>category-list">
                                               <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                               <span class="pcoded-mtext" data-i18n="nav.basic-components.alert">Category List</span>
                                               <span class="pcoded-mcaret"></span>
                                           </a>
                                       </li>
                              
                                 
                                       
                           
                                   </ul>
                               </li>
                             <?php } if($authority[7]==8){ ?>

                                     <li class="<?php echo ($page == "about.php" ? "active" : "")?>">
                                   <a href="about.php">
                                       <span class="pcoded-micon"><i class="ti-harddrives"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">About us</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                             <?php } if($authority[8]==9){ ?>

                                  <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="contact.php">
                                       <span class="pcoded-micon"><i class="ti-email"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Contact us</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                             <?php } if($authority[9]==10){ ?>

                                    <li class="<?php echo ($page == "profile" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>profile">
                                       <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">My Profile</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                             <?php } if($authority[10]==11){ ?>
                                    <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="contact.php">
                                       <span class="pcoded-micon"><i class="ti-settings"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Setting</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
                             <?php }  ?>
                              <li class="<?php echo ($page == "profile" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>profile">
                                       <span class="pcoded-micon"><i class="ti-user"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">My Profile</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>
     <li class="<?php echo ($page == "contact.php" ? "active" : "")?>">
                                   <a href="<?php echo base_url(); ?>backend/Login/logout">
                                       <span class="pcoded-micon"><i class="ti-power-off"></i><b>D</b></span>
                                       <span class="pcoded-mtext" data-i18n="nav.dash.main">Logout</span>
                                       <span class="pcoded-mcaret"></span>
                                   </a>
                               </li>                               
                           </ul> 
                            <?php } ?>
                        </div>
                    </nav>




                  

<!-- The Users Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title name">Vendor</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="user_detail"></div>
         <div class="card user-card">
                                                    <div class="card-header">
                                                        <h5 class="">Profile</h5>
                                                    </div>
                                                    <div class="card-block">
                                                        <div class="usre-image profile_pic">
                                                            
                                                        </div>
                                                        <h6 class="f-w-600 m-t-25 m-b-10">Alessa Robert</h6>
                                                        <p class="text-muted">Active | Male | Born 23.05.1992</p>
                                                        <hr/>
                                                        <p class="text-muted m-t-15">Activity Level: 87%</p>
                                                        <ul class="list-unstyled activity-leval">
                                                            <li class="active"></li>
                                                            <li class="active"></li>
                                                            <li class="active"></li>
                                                            <li></li>
                                                            <li></li>
                                                        </ul>
                                                        <div class="bg-c-blue counter-block m-t-10 p-20">
                                                            <div class="row">
                                                                <div class="col-4">
                                                                    <i class="ti-comments"></i>
                                                                    <p>1256</p>
                                                                </div>
                                                                <div class="col-4">
                                                                    <i class="ti-user"></i>
                                                                    <p>8562</p>
                                                                </div>
                                                                <div class="col-4">
                                                                    <i class="ti-bag"></i>
                                                                    <p>189</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p class="m-t-15 text-muted">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        <hr/>
                                                        <div class="row justify-content-center user-social-link">
                                                            <div class="col-auto"><a href="#!"><i class="fa fa-facebook text-facebook"></i></a></div>
                                                            <div class="col-auto"><a href="#!"><i class="fa fa-twitter text-twitter"></i></a></div>
                                                            <div class="col-auto"><a href="#!"><i class="fa fa-dribbble text-dribbble"></i></a></div>
                                                        </div>
                                                    </div>
                                                </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<!-- The Venders Modal -->
<div class="modal" id="myModal2">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title name">Vendor</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <div class="user_detail"></div>
         <div class="card user-card">
                                                    <div class="card-header">
                                                        <h5 class="">Profile</h5>
                                                    </div>
                                                    <div class="email"></div>
                                                    
                                                    <div class="national_id"></div>
                                                     <div class="business_proof"></div>
                                                    <div class="address"></div>
                                                    <div class="latitude"></div>
                                                    <div class="longitude"></div>
                                                    <div class="contact"></div>
                                                    <div class="city"></div>
                                                    <div class="menu_pdf"></div>
                                                    <div class="card-block">
                                                        <div class="usre-image profile_pic">
                                                            
                                                        </div>
                                                        <h6 class="f-w-600 m-t-25 m-b-10">Alessa Robert</h6>
                                                        <p class="text-muted">Active | Male | Born 23.05.1992</p>
                                                        <hr/>
                                                        <p class="text-muted m-t-15">Activity Level: 87%</p>
                                                        <ul class="list-unstyled activity-leval">
                                                            <li class="active"></li>
                                                            <li class="active"></li>
                                                            <li class="active"></li>
                                                            <li></li>
                                                            <li></li>
                                                        </ul>
                                                        <div class="bg-c-blue counter-block m-t-10 p-20">
                                                            <div class="row">
                                                                <div class="col-4">
                                                                    <i class="ti-comments"></i>
                                                                    <p>1256</p>
                                                                </div>
                                                                <div class="col-4">
                                                                    <i class="ti-user"></i>
                                                                    <p>8562</p>
                                                                </div>
                                                                <div class="col-4">
                                                                    <i class="ti-bag"></i>
                                                                    <p>189</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p class="m-t-15 text-muted">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        <hr/>
                                                        <div class="row justify-content-center user-social-link">
                                                            <div class="col-auto"><a href="#!"><i class="fa fa-facebook text-facebook"></i></a></div>
                                                            <div class="col-auto"><a href="#!"><i class="fa fa-twitter text-twitter"></i></a></div>
                                                            <div class="col-auto"><a href="#!"><i class="fa fa-dribbble text-dribbble"></i></a></div>
                                                        </div>
                                                    </div>
                                                </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
<!-- News add model -->
<div class="modal" id="news-section">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add News Section</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     
      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               
               <div class="col-xl-12">
                 <form action="#" method="post">
                  <div class="form-group news_save" style="display: none;" id="successMessage">
                     <div class="alert alert-success">
  <strong>News Save Successfully.</strong>
</div>
                   </div>
                   <div class="form-group">
                     <label>Title</label>
                     <input type="text"  name="title" class="form-control title">
                   </div>
                   <div class="form-group">
                     <label>text</label>
                     <input type="text"  name="text" class="form-control text">
                   </div>
                    
                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger save_news">submit</button>
      </div>

    </div>
  </div>
</div>
<!-- News update model -->
<div class="modal" id="news-update">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update News Section</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
     
      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               
               <div class="col-xl-12">
                 <form action="#" method="post">
                  <div class="form-group news_update" style="display: none;" id="successMessage">
                     <div class="alert alert-success">
  <strong>News Update Successfully.</strong>
</div>
                   </div>

                   <div class="form-group">
                     <label>Title</label>
                     <input type="text" id="title"  name="title" value="" class="form-control title">
                   </div>
                   <div class="form-group">
                     <label>text</label>
                     <input type="hidden" value="" name="id" value="" class="id">
                     <input type="text" id="text" value="" name="text" class="form-control text">
                   </div>
                    
                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger update_news">submit</button>
      </div>

    </div>
  </div>
</div>
<!-- category Modal -->
<div class="modal" id="category-section">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Category</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="modal_form_id"  method="POST" >
                  
                   <div class="form-group">
                     <label>Category Name</label>
                     <input type="text" name="name" id="name" class="form-control">
                   </div>
                  
                    <div class="form-group">
                     <label>Image</label>
                     <input type="file" name="userfile" id="userfile" class="form-control">
                   </div>

                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger category_save">submit</button>
      </div>

    </div>
  </div>
</div>
<!-- category Modal update-->
<div class="modal" id="category-update">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Category</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="modal_form_id2"  method="POST" >
                  
                   <div class="form-group">
                     <label>Category Name</label>
                     <input type="text" name="name" id="name" class="form-control name">
                   </div>
                   <input type="hidden" name="id" value="" class="id">
                   <input type="hidden" name="featured_image" value="" class="featured_image">
                   <div class="featured_image"></div>
                    <div class="form-group">
                     <label>Image</label>
                     <input type="file" name="userfile" id="userfile" class="form-control userfile">
                   </div>

                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger category_update">submit</button>
      </div>

    </div>
  </div>
</div>
<!--sub category Modal -->
<div class="modal" id="sub-category-section">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Sub Category</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="subcate"  method="POST" >
                  <div class="form-group">
                  <label>Category Name</label>
                  <select class="category_list form-control" name="c_id" id="c_id">
                    <option>Select Category</option>
                  </select>
                   </div>
                   <div class="form-group">
                     <label>Sub Category Name</label>
                     <input type="text" name="name" id="name" class="form-control">
                   </div>
                  
                    <div class="form-group">
                     <label>Image</label>
                     <input type="file" name="userfile" id="userfile" class="form-control">
                   </div>

                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger subcategory_save">submit</button>
      </div>

    </div>
  </div>
</div>
<!-- subcategory Modal update-->
<div class="modal" id="subcategory-update">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update SubCategory</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="subcateupdate"  method="POST" >
                  <div class="form-group">
                  <label>Category Name</label>
                  <select class="category_list form-control" name="c_id" id="c_id">
                    <option>Select Category</option>
                  </select>
                   </div>
                   <div class="form-group">
                     <label>SubCategory Name</label>
                     <input type="text" name="name" id="name" class="form-control name">
                   </div>
                   <input type="hidden" name="id" value="" class="id">
                   <input type="hidden" name="featured_image" value="" class="featured_image">
                   <div class="featured_image"></div>
                    <div class="form-group">
                     <label>Image</label>
                     <input type="file" name="userfile" id="userfile" class="form-control userfile">
                   </div>

                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger subcategory_update">submit</button>
      </div>

    </div>
  </div>
</div>
<!-- Vender Offer Modal -->
<div class="modal" id="Vender_offer">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Offer Detail</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="subcateupdate"  method="POST" >
                    
                    <div class="row">
                        <div class="col-xl-4">
                            <div  class="offer_img"></div>
                        </div>
                        <div class="col-xl-8">
                       <div class="view_information">
                 <div>offer title:</div> 
                 <div class="offer_title"></div>
                 </div>
                 
                   <div class="view_information"> <div>offer_name:</div><div class="offer_name"></div></div>
                   <div class="view_information"> <div>offer_detail:</div><div class="offer_detail"></div></div>
                   <div class="view_information"> <div>valid_date:</div><div class="valid_date"></div></div>
                    <div class="view_information"><div>limit_per_user:</div><div class="limit_per_user"></div></div>
                    <div class="view_information"><div>stoke:</div><div class="stoke"></div></div>
                    <div class="view_information"><div>used:</div><div class="used"></div></div>
                    <div class="view_information"><div>offer_amount:</div><div class="offer_amount"></div></div>
                   <div class="view_information"> <div>add_date:</div><div class="add_date"></div></div>
                   <div class="view_information"> <div>status:</div><div class="status"></div></div>
                        </div>
                    </div>
                    </div>
                
              

                 </form>
               </div>
             </div>
      </div>


    </div>
  </div>
</div>
<!--Aminity Modal -->
<div class="modal" id="aminity-section">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Aminity</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="aminity"  method="POST" >
                  <div class="form-group">
                  <label>Category Name</label>
                  <select class="category_list form-control" name="c_id" id="c_id">
                    <option>Select Category</option>
                  </select>
                   </div>
                   <div class="form-group">
                     <label>Aminity Name</label>
                     <input type="text" name="name" id="name" class="form-control">
                   </div>
                  
                    <div class="form-group">
                     <label>Image</label>
                     <input type="file" name="userfile" id="userfile" class="form-control">
                   </div>

                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger aminity_save">submit</button>
      </div>

    </div>
  </div>
</div>
<!-- aminity update Modal update-->
<div class="modal" id="aminity-update">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Update Aminity</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
             <div class="row">
               <div class="col-xl-12">
                
                <form enctype="multipart/form-data" id="aminityupdate"  method="POST" >
                  <div class="form-group">
                  <label>Category Name</label>
                  <select class="category_list form-control" name="c_id" id="c_id">
                    <option>Select Category</option>
                  </select>
                   </div>
                   <div class="form-group">
                     <label>SubCategory Name</label>
                     <input type="text" name="name" id="name" class="form-control name">
                   </div>
                   <input type="hidden" name="id" value="" class="id">
                   <input type="hidden" name="featured_image" value="" class="featured_image">
                   <div class="featured_image"></div>
                    <div class="form-group">
                     <label>Image</label>
                     <input type="file" name="userfile" id="userfile" class="form-control userfile">
                   </div>

                 </form>
               </div>
             </div>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger aminity_update">submit</button>
      </div>

    </div>
  </div>
</div>