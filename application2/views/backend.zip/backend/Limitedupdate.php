
<div class="pcoded-content">
   <div class="pcoded-inner-content">
      <div class="main-body">
         <div class="page-wrapper">
            <div class="page-body">
               <div class="row">
                  <!-- order-card start -->
                  <div class="col-sm-12">
                          <div class="card">
                            <div class="card-header">
                              <h4>Limited Offer update</h4>
                            </div>
                            <div class="card-body">
                              <form action="<?php echo base_url(); ?>limited_offer_updatedata" method="post" enctype="multipart/form-data">
                                <?php if( $error = $this->session->flashdata('lmtd_offer_save')): ?>
        <div class="form-group">
              <div class="input-icon">
        <div class="alert alert-dismissible alert-success" id="successMessage">
          <?php echo $error; ?>
        </div>
      </div>
    </div>
  <?php endif; ?>
                              <div class="form-group">
                                <label for="">Vendor Name</label>
                                <select class="form-control" name="vendor_id" required="">
                                  <option value="<?php print_r($get_limited[0]['vendor_id']) ?>"><?php  $data['vender_view'] =$this->Modlogin->vender_view($get_limited[0]['vendor_id']); print_r($data['vender_view'][0]['name']); ?></option>
                       <?php  foreach ($all_venders_list as $key) {  ?>
                               
                               <option value="<?php echo $key->id; ?>"><?php echo $key->name; ?></option>   
                       <?php } ?>
                                </select>
                              </div>
                                <div class="form-group">
                                <label for="">Category Name</label>
                                <input type="text" name="category_name" class="form-control" value="<?php print_r($get_limited[0]['category_name']) ?>" required="required">
                              </div>
                              <input type="hidden" name="id" value="<?php print_r($get_limited[0]['id']) ?>">
                              <input type="hidden" name="images" value="<?php print_r($get_limited[0]['image']) ?>">
                              <input type="hidden" name="pdfs" value="<?php print_r($get_limited[0]['pdf']) ?>">

                              
                              
     
                               <div class="form-group">
                                <label for="">Shop name</label>
                                <input type="text" name="shop_name" class="form-control" value="<?php print_r($get_limited[0]['shop_name']) ?>" >
                              </div>

                                <div class="form-group">
                                <label for="">section</label>
                                <input type="text" name="section" value="<?php print_r($get_limited[0]['section']) ?>" class="form-control">
                              </div>

                              <div class="form-group">
                                <label for="">Image</label>
                                <img style="width: 10%;" src="<?php echo base_url(); ?>assets/images/limited/<?php print_r($get_limited[0]['image']) ?>">
                              <input type="file" name="files[]">
                              </div>
                              <div class="form-group">
                                <label for="">Pdf</label>
                                <a target="_blank" href="<?php echo base_url(); ?>assets/images/limited/<?php print_r($get_limited[0]['pdf']) ?>">Click here for pdf view</a>
                              <input type="file" name="files[]">
                              </div>

                              <div class="form-group">
                                <label for="">Region</label>
                                <input type="text" name="region" value="<?php print_r($get_limited[0]['region']) ?>" class="form-control" required="required">
                              </div>
                             
                            
                                   <div class="float-right">
                                      <input type="submit" name="submit" value="submit" class="btn btn-success">
                                   </div>
                               </form>
                            
                          </div>
                   </div>
              </div>
          </div>
      </div>
  </div>
</div>
</div>



