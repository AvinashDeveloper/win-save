<div class="pcoded-content">
  <div class="pcoded-inner-content">
    <div class="main-body">
      <div class="page-wrapper">
        <div class="page-body">
          <div class="row">
            <!-- order-card start -->
           
            <div class="col-sm-12">
              <div class="card">
                 <?php if( $error=$this->session->flashdata('confirm_order')): ?>
                    <div class="form-group">
                      <div class="input-icon">
                        <div class="alert alert-dismissible alert-success" id="successMessage">
                          <?php echo $error; ?>
                        </div>
                      </div>
                    </div>
                    <?php endif; ?>
                   
                <div class="card-header">
                  <h4>Offer Redeem</h4>
                </div>
                <div class="card-body">
                  <form action="<?php echo base_url(); ?>checkRedeem" method="post" enctype="multipart/form-data">
                   
                    <div class="form-group">
                      <label for="">Enter User Code</label>
                     <input type="number" name="generated_code" placeholder="Enter User Code" class="form-control" value="">
                    </div>
                    <div class="float-right">
                      <input type="submit" name="submit" value="submit" class="btn btn-success">
                    </div>
                   
                  </form>

                </div>
              </div>
            </div>
          
           
           
          </div>
        </div>
      </div>
    </div>
  </div>