
<div class="pcoded-content">
   <div class="pcoded-inner-content">
      <div class="main-body">
         <div class="page-wrapper">
            <div class="page-body">
               <div class="row">
                  <!-- order-card start -->
                  <div class="col-sm-12">
                          <div class="card">
                          	<div class="card-header">
                          		<h4>Classified Offer update</h4>
                          	</div>
                          	<div class="card-body">
                          		<form action="<?php echo base_url(); ?>cls_offer_updatedata" method="post" enctype="multipart/form-data">
                                <?php if( $error = $this->session->flashdata('cls_update')): ?>
        <div class="form-group">
              <div class="input-icon">
        <div class="alert alert-dismissible alert-success" id="successMessage">
          <?php echo $error; ?>
        </div>
      </div>
    </div>
  <?php endif; ?>
                          		<div class="form-group">
                          			<label for="">Vendor Name</label>
                          			<select class="form-control" name="vendor_id" required="">
                                  <option value="<?php  print_r($get_cls[0]['vendor_id'])  ?>"><?php  print_r($get_cls[0]['vendor_id'])  ?></option>
                       <?php  foreach ($all_venders_list as $key) {  ?>
                               
                               <option value="<?php echo $key->id; ?>"><?php echo $key->name; ?></option>   
                       <?php } ?>
                                </select>
                          		</div>
                          			<div class="form-group">
                          			<label for="">Category Name</label>
                          			<input type="text" name="category_name" class="form-control" value="<?php  print_r($get_cls[0]['category_name'])  ?>" required="required">
                          		</div>
                          		
                          		
     
                     	         <div class="form-group">
                          			<label for="">caption</label>
                          			<input type="text" name="caption" class="form-control" value="<?php  print_r($get_cls[0]['caption'])  ?>" >
                          		</div>

                          			<div class="form-group">
                          			<label for="">section</label>
                          			<input type="text" name="section" value="<?php  print_r($get_cls[0]['section'])  ?>" class="form-control">
                          		</div>

                          		<div class="form-group">
                          			<label for="">Image</label>
                                
                          		<input type="file" name="userfile">
                              <img style="width: 10%;" src="<?php echo base_url(); ?>assets/images/vendors/offers/<?php  print_r($get_cls[0]['image'])  ?>">
                          		</div>
                              <input type="hidden" name="id" value="<?php  print_r($get_cls[0]['id'])  ?>">
                                <input type="hidden" name="images" value="<?php  print_r($get_cls[0]['image'])  ?>">
                          		<div class="form-group">
                          			<label for="">duration</label>
                          			<input type="date" name="duration" id='datetimepicker1' value="<?php  print_r($get_cls[0]['duration'])  ?>" class="form-control">
                          		</div>
                              <div class="form-group">
                                <label for="">region</label>
                                <input type="text" name="region" value="<?php  print_r($get_cls[0]['region'])  ?>" class="form-control" required="required">
                              </div>
                              <div class="form-group">
                                <label for="">link</label>
                                <input type="text" name="link" value="<?php  print_r($get_cls[0]['link'])  ?>" class="form-control" required="required">
                              </div>
                                   <div class="float-right">
                                   		<input type="submit" name="submit" value="submit" class="btn btn-success">
                                   </div>
                               </form>
                          	
                          </div>
                   </div>
              </div>
          </div>
      </div>
  </div>
</div>
</div>
<script type="text/javascript">
            $(function () {
                $('#datetimepicker1').datetimepicker();
            });
        </script>


